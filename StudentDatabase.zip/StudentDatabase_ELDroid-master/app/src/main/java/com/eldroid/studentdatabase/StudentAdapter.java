package com.eldroid.studentdatabase;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.activity.result.ActivityResultLauncher;
import java.util.ArrayList;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {

    private final Context context;
    private final ActivityResultLauncher<Intent> editLauncher;
    private final StudentDatabaseHelper dbHelper;

    private final List<Student> students = new ArrayList<>();
    private final List<Student> allStudents = new ArrayList<>();

    public StudentAdapter(Context ctx, List<Student> list, ActivityResultLauncher<Intent> launcher) {
        context = ctx;
        editLauncher = launcher;
        dbHelper = new StudentDatabaseHelper(ctx);
        setData(list);
    }

    public void setData(List<Student> list) {
        students.clear();
        allStudents.clear();
        students.addAll(list);
        allStudents.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_student, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        Student s = students.get(pos);
        h.name.setText(s.getName());
        h.course.setText(s.getCourse());

        if (s.getImageUri() != null && !s.getImageUri().isEmpty())
            h.image.setImageURI(Uri.parse(s.getImageUri()));
        else
            h.image.setImageResource(R.drawable.more_options_icon);

        // Open item on click
        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, MainActivity2.class);
            i.putExtra("id", s.getId());
            editLauncher.launch(i);
        });

        // Popup menu
        h.moreBtn.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(context, h.moreBtn);
            popup.inflate(R.menu.action_btns);
            popup.setOnMenuItemClickListener(menuItem -> {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.action_edit) {
                    Intent i = new Intent(context, MainActivity2.class);
                    i.putExtra("id", s.getId());
                    editLauncher.launch(i);
                    return true;
                } else if (itemId == R.id.action_delete) {
                    int deleted = dbHelper.deleteStudent(s.getId());
                    if (deleted > 0) {
                        Toast.makeText(context, "Deleted: " + s.getName(), Toast.LENGTH_SHORT).show();
                        allStudents.remove(s);
                        students.remove(pos);
                        notifyItemRemoved(pos);
                    } else {
                        Toast.makeText(context, "Deletion failed!", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return students.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void filter(String text) {
        students.clear();
        if (text == null || text.trim().isEmpty()) {
            students.addAll(allStudents);
        } else {
            String query = text.toLowerCase();
            for (Student s : allStudents) {
                if (s.getName().toLowerCase().startsWith(query)) {
                    students.add(s);
                }
            }
        }
        notifyDataSetChanged();
    }

    public List<Student> getStudentList() {
        return students;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image, moreBtn;
        TextView name, course;

        ViewHolder(View v) {
            super(v);
            image = v.findViewById(R.id.imgProfile);
            moreBtn = v.findViewById(R.id.moreBtn);
            name = v.findViewById(R.id.txtName);
            course = v.findViewById(R.id.txtCourse);
        }
    }
}
